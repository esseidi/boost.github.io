self.__precacheManifest = [
  {
    "revision": "fa1f99dc4c40e5a082e31222a2f2436e",
    "url": "/static/media/AraJozoor-Regular.fa1f99dc.eot"
  },
  {
    "revision": "a5db36d2f7f45d7e526b",
    "url": "/static/css/main.ac341eb3.chunk.css"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.42ac5946.js"
  },
  {
    "revision": "5a43dec2b91f6cbb4d6d62dfb83da50a",
    "url": "/static/media/009-cloudy-night.5a43dec2.svg"
  },
  {
    "revision": "74ed3b035db61170e744",
    "url": "/static/js/2.74ed3b03.chunk.js"
  },
  {
    "revision": "b573015b8452e0f4eb977bbfb193f03f",
    "url": "/static/media/AraJozoor-Regular.b573015b.woff"
  },
  {
    "revision": "f2b8b184ba39f851059aeada97db517b",
    "url": "/static/media/AraJozoor-Regular.f2b8b184.svg"
  },
  {
    "revision": "289cda261d2a7d3e6e853b30e16d718a",
    "url": "/static/media/AraJozoor-Regular.289cda26.ttf"
  },
  {
    "revision": "a5db36d2f7f45d7e526b",
    "url": "/static/js/main.a5db36d2.chunk.js"
  },
  {
    "revision": "28157ec23ba997350570797d304ca708",
    "url": "/static/media/016-cloudy-night-3.28157ec2.svg"
  },
  {
    "revision": "1f69a3e9e85c2ed02d73bfc813c0efec",
    "url": "/static/media/002-sunrise.1f69a3e9.svg"
  },
  {
    "revision": "004ec82a40d4fadb92b08d52fc464dcb",
    "url": "/static/media/001-sun.004ec82a.svg"
  },
  {
    "revision": "aa8cc3774681f3f899e2ac4105fac807",
    "url": "/static/media/015-cloudy-day-1.aa8cc377.svg"
  },
  {
    "revision": "53a38aace3bcc6b79631ab4755ceba72",
    "url": "/static/media/003-sunset.53a38aac.svg"
  },
  {
    "revision": "74ed3b035db61170e744",
    "url": "/static/css/2.1f857138.chunk.css"
  },
  {
    "revision": "0f60c3d6e630c7f390cb3d4002a86caa",
    "url": "/index.html"
  }
];